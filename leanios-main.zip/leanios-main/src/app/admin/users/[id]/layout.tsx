export default function UserDetailsLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return children
}