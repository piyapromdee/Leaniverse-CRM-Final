import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Shield, Users, Settings, Zap, Globe, Lock } from 'lucide-react'

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold text-gray-900">LeaniOS</h1>
            </div>
            <div className="flex items-center space-x-4">
              <Link href="/auth/sign-in">
                <Button variant="outline">Sign In</Button>
              </Link>
              <Link href="/auth/sign-up">
                <Button>Get Started</Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
            Welcome to <span className="text-blue-600">LeaniOS</span>
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            A modern web application boilerplate built with Next.js, TypeScript, TailwindCSS, 
            Shadcn/ui, and Supabase. Everything you need to start building your next project.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/auth/sign-up">
              <Button size="lg" className="w-full sm:w-auto">
                Get Started Free
              </Button>
            </Link>
            <Link href="/auth/sign-in">
              <Button variant="outline" size="lg" className="w-full sm:w-auto">
                Sign In
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Features</h2>
            <p className="text-lg text-gray-600">Everything you need to build modern web applications</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card>
              <CardHeader>
                <Shield className="h-10 w-10 text-blue-600 mb-2" />
                <CardTitle>Authentication</CardTitle>
                <CardDescription>
                  Built-in authentication with Supabase including sign-up, sign-in, and user management
                </CardDescription>
              </CardHeader>
            </Card>
            <Card>
              <CardHeader>
                <Users className="h-10 w-10 text-green-600 mb-2" />
                <CardTitle>User Dashboard</CardTitle>
                <CardDescription>
                  Complete user dashboard with profile management, settings, and personalized content
                </CardDescription>
              </CardHeader>
            </Card>
            <Card>
              <CardHeader>
                <Settings className="h-10 w-10 text-purple-600 mb-2" />
                <CardTitle>Admin Panel</CardTitle>
                <CardDescription>
                  Comprehensive admin area for managing users, global settings, and system configuration
                </CardDescription>
              </CardHeader>
            </Card>
            <Card>
              <CardHeader>
                <Zap className="h-10 w-10 text-yellow-600 mb-2" />
                <CardTitle>Modern Stack</CardTitle>
                <CardDescription>
                  Built with Next.js 15, TypeScript, TailwindCSS, and Shadcn/ui for optimal performance
                </CardDescription>
              </CardHeader>
            </Card>
            <Card>
              <CardHeader>
                <Globe className="h-10 w-10 text-indigo-600 mb-2" />
                <CardTitle>Responsive Design</CardTitle>
                <CardDescription>
                  Mobile-first responsive design that works perfectly on all devices and screen sizes
                </CardDescription>
              </CardHeader>
            </Card>
            <Card>
              <CardHeader>
                <Lock className="h-10 w-10 text-red-600 mb-2" />
                <CardTitle>Security First</CardTitle>
                <CardDescription>
                  Built with security best practices including middleware protection and role-based access
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      {/* Tech Stack Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Tech Stack</h2>
            <p className="text-lg text-gray-600">Built with modern technologies and best practices</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-8">
            {[
              'Next.js 15',
              'TypeScript',
              'TailwindCSS',
              'Shadcn/ui',
              'Supabase'
            ].map((tech) => (
              <div key={tech} className="text-center">
                <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
                  <h3 className="font-semibold text-gray-900">{tech}</h3>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-blue-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Ready to get started?</h2>
          <p className="text-xl text-blue-100 mb-8">
            Join thousands of developers building amazing applications with LeaniOS
          </p>
          <Link href="/auth/sign-up">
            <Button size="lg" variant="secondary">
              Start Building Today
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h3 className="text-2xl font-bold mb-4">LeaniOS</h3>
            <p className="text-gray-400 mb-6">
              The modern web application boilerplate for developers
            </p>
            <p className="text-gray-500">
              © 2024 LeaniOS. Built with ❤️ for developers.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}
